<?php
defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Clean Grade Report';
$string['printcleanreport'] = 'Print Clean Report';
$string['gradereport'] = 'Grade Report';
$string['gradeitem'] = 'Grade Item';
$string['calculatedweight'] = 'Calculated Weight';
$string['grade'] = 'Grade';
$string['lettergrade'] = 'Letter Grade';
$string['privacy:metadata'] = 'The Clean Grade Report plugin does not store any personal data.';
